package seleniumjavatest;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Selenium_Java {
//	private WebDriver driver;
//    private String browserName;
//    private String browserVersion;
//    private String platform;
//    private String url;
//	@SuppressWarnings("deprecation")
//	@Parameters({"browser", "browserVersion", "platform", "url"})
//    @BeforeMethod
//    public void setUp(String browser, String browserVersion, String platform, String url) throws MalformedURLException {
//        this.browserName = browser;
//        this.browserVersion = browserVersion;
//        this.platform = platform;
//        this.url = url;
//       ChromeOptions browserOptions = new ChromeOptions();
//       System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
//       driver = new ChromeDriver();
//        DesiredCapabilities capabilities = new DesiredCapabilities();
//		capabilities.setCapability("browserName",browserName);
//		capabilities.setCapability("browserVersion", browserVersion);
//		capabilities.setCapability("platformName", platform);
//		HashMap<String, Object> option1 = new HashMap<String, Object>();
//		option1.put("username", "shubham_dokhale");
//		option1.put("accessKey", "UDWxxmumF1IvMfg0ZvicqAugJ8lkgLxuIksp0cyffkUnh2OI5n");
//		option1.put("visual", true);
//		option1.put("video", true);
//		option1.put("network", true);
//		option1.put("build", "Lambda Test Automation");
//		option1.put("project", "Selenium 101 certification");
//		option1.put("name", "Test");
//		option1.put("console", "true");
//		option1.put("w3c", true);
//		option1.put("plugin", "java-testNG");
//		capabilities.setCapability("LT:Options", option1);	
//		driver=new RemoteWebDriver(new URL("https://shubham_dokhale:UDWxxmumF1IvMfg0ZvicqAugJ8lkgLxuIksp0cyffkUnh2OI5n@hub.lambdatest.com/wd/hub"),capabilities);
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
//        driver.manage().window().maximize();
//        driver.get(url);
//    }
	
    public String username = "shubham_dokhale";
    public String accesskey = "UDWxxmumF1IvMfg0ZvicqAugJ8lkgLxuIksp0cyffkUnh2OI5n";
    public String gridURL = "@hub.lambdatest.com/wd/hub";
    RemoteWebDriver driver;
 
	@BeforeMethod
   // @Parameters(value = { "Browser", "Version", "Platform","url" })
  //  public void setUp(String browser, String version, String platform, String url) throws MalformedURLException {
		public void setUp() throws MalformedURLException {
        DesiredCapabilities cap = new DesiredCapabilities();
        cap.setCapability("browserName","MicrosoftEdge");
        cap.setCapability("browserVersion", "127.0");
        //cap.setCapability("platformName", "macOS Ventura");
 
        HashMap<String, Object> ltOptions = new HashMap<String, Object>();
        ltOptions.put("username", "shubham_dokhale");
        ltOptions.put("accessKey", "UDWxxmumF1IvMfg0ZvicqAugJ8lkgLxuIksp0cyffkUnh2OI5n");
        ltOptions.put("visual", true);
        ltOptions.put("video", true);
        ltOptions.put("network", true);
        ltOptions.put("build", "TestBuildV1.1");
        ltOptions.put("console", true);
        ltOptions.put("terminal", true);
        ltOptions.put("devicelog", true);
        ltOptions.put("project", "DemoSeleniumJava101Project");
        ltOptions.put("selenium_version", "4.0.0");
        cap.setCapability("LT:Options", ltOptions);
        driver = new RemoteWebDriver(new URL("https://" + username + ":" + accesskey + gridURL), cap);
 
        ((WebDriver) driver).manage().window().maximize();
        ((WebDriver) driver).manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
        driver.get("https://www.lambdatest.com/selenium-playground/");
    }

	 @Test (enabled=true)
	    public void testSimpleFormDemo() {
	        driver.findElement(By.linkText("Simple Form Demo")).click();

	        Assert.assertTrue(driver.getCurrentUrl().contains("simple-form-demo"), "URL does not contain 'simple-form-demo'");
	        String message = "Welcome to LambdaTest";

	        driver.findElement(By.id("user-message")).sendKeys(message);
	        // Click the "Get Checked Value" button
	        driver.findElement(By.xpath("//*[@id='showInput']")).click();
	        // Validate the message is displayed in the right-hand panel
	        WebElement outputMessage = driver.findElement(By.id("message"));
	        Assert.assertEquals(outputMessage.getText(), message, "The message displayed does not match the input.");
	    }

	    @Test
//	    (enabled=true)
	    public void testDragAndDropSliders() {

	        driver.findElement(By.linkText("Drag & Drop Sliders")).click();
	        WebElement slider = driver.findElement(By.xpath("//input[@value='15']"));
	        Actions actions = new Actions(driver);
	        // Drag the slider to 95
	        actions.dragAndDropBy(slider, 215, 0).perform();
	        // Validate that the slider value is 95
	        WebElement sliderValue = driver.findElement(By.id("rangeSuccess"));
	        Assert.assertEquals(sliderValue.getText(), "95", "Slider value is not 95.");
	    }

		@Test
//		(enabled=true)
	    public void testInputFormSubmit() throws InterruptedException {

	        driver.findElement(By.linkText("Input Form Submit")).click();

	        driver.findElement(By.xpath("//*[text()='Submit']")).click();
	        Thread.sleep(2000);
	        // Assert "Please fill out this field." error message
//	        WebElement nameError = driver.findElement(By.id("name"));
//	       Assert.assertTrue(nameError.getDomAttribute("validationMessage").contains("Please fill out this field."), "Error message for Name is not correct.");

	        // Fill in the form
	        driver.findElement(By.id("name")).sendKeys("John Doe");
	        driver.findElement(By.id("inputEmail4")).sendKeys("johndoe@example.com");
	        driver.findElement(By.id("inputPassword4")).sendKeys("1234567890");
	        driver.findElement(By.id("company")).sendKeys("PSL");
	        driver.findElement(By.id("websitename")).sendKeys("PSL.com");
	        driver.findElement(By.id("inputCity")).sendKeys("Bengaluru");
	        driver.findElement(By.id("inputAddress1")).sendKeys("Test message.");
	        driver.findElement(By.id("inputAddress2")).sendKeys("Test message.");
	        driver.findElement(By.id("inputState")).sendKeys("Karnataka");
	        driver.findElement(By.id("inputZip")).sendKeys("560045");
	        Select countryDropdown = new Select(driver.findElement(By.xpath("//*[@name='country']")));
	        countryDropdown.selectByVisibleText("United States");

	        driver.findElement(By.xpath("//*[text()='Submit']")).click();
	        WebElement successMessage = driver.findElement(By.cssSelector(".success-msg"));
	        Assert.assertTrue(successMessage.getText().contains("Thanks for contacting us, we will get back to you shortly."), "Success message is not displayed.");
	    }


    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

}
