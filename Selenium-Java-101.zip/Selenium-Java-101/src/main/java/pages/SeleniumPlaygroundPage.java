package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumPlaygroundPage extends BasePage {

	private By lnkSimpleFormDemo = By.linkText("Simple Form Demo");
	private By lnkDragAndDropSlider = By.linkText("Drag & Drop Sliders");
	private By lnkInputFormSubmit = By.linkText("Input Form Submit");

	public String getPageTitle() {
		String strTitle = driver.getTitle();
		System.out.println("Page title is: "+strTitle);
		return strTitle;
	} 
	
	public void clickOnSimpleFormDemoLink() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(lnkSimpleFormDemo ));
		click(lnkSimpleFormDemo);
	}
	
	public void clickOnDragAndDropSliderLink() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(lnkDragAndDropSlider ));
		click(lnkDragAndDropSlider);
	}
	
	public void clickOnInputFormSubmitLink() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(lnkInputFormSubmit ));
		click(lnkInputFormSubmit);
	}

	
}
