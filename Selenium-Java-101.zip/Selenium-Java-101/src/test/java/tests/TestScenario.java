package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.FormDemoPage;
import pages.SeleniumPlaygroundPage;
import pages.SimpleFormDemoPage;
import pages.SliderDemoPage;

public class TestScenario extends BaseTestClass {
	SoftAssert softAssert = new SoftAssert();


	SeleniumPlaygroundPage seleniumPlaygroundPage = new SeleniumPlaygroundPage();
	SimpleFormDemoPage simpleFormDemoPage = new SimpleFormDemoPage();
	SliderDemoPage sliderDemoPage = new SliderDemoPage();
	FormDemoPage formDemoPage = new FormDemoPage();

	@Test(priority=1, timeOut = 20000)
	public void TC01_SimpleFormDemo() {
		
		String txtValue = "Welcome to LambdaTest.";
		
		Assert.assertEquals(seleniumPlaygroundPage.getPageTitle(), "Selenium Grid Online | Run Selenium Test On Cloud", "\n Actual and expected page tile is not same \n");
		seleniumPlaygroundPage.clickOnSimpleFormDemoLink();
		
		Assert.assertEquals(simpleFormDemoPage.getSimpleFormDemoLabel(), "Simple Form Demo", "\n Actual and expected page header is not same \n");
		Assert.assertEquals(simpleFormDemoPage.getPageURL().contains("simple-form-demo"), true, "\n Actual URL does not contains expected url value \n");
		simpleFormDemoPage.enterMessage(txtValue);
		simpleFormDemoPage.clickOnGetCheckedValue();
		
		Assert.assertEquals(simpleFormDemoPage.getYourMessage(), txtValue, "\n Actual and expected message is not same \n");
	}
	
	@Test(priority=2, timeOut = 20000)
	public void TC02_DragAndDropSlider() {
		
		Assert.assertEquals(seleniumPlaygroundPage.getPageTitle(), "Selenium Grid Online | Run Selenium Test On Cloud", "\n Actual and expected page tile is not same \n");
		seleniumPlaygroundPage.clickOnDragAndDropSliderLink();
		
		Assert.assertEquals(sliderDemoPage.getSliderDemoLabel(), "Slider Demo", "\n Actual and expected page header is not same \n");
		Assert.assertEquals(sliderDemoPage.getSlider3Value(), "15", "\n Actual and expected range value is not same \n");
		sliderDemoPage.setSliderRangeTo95();
		Assert.assertEquals(sliderDemoPage.getSlider3Value(), "95", "\n Actual and expected range value is not same \n");
	}

	@Test(priority=3, timeOut = 20000)
	public void TC03_InputFormSubmit() throws InterruptedException {
		
		Assert.assertEquals(seleniumPlaygroundPage.getPageTitle(), "Selenium Grid Online | Run Selenium Test On Cloud", "\n Actual and expected page tile is not same \n");
		seleniumPlaygroundPage.clickOnInputFormSubmitLink();

		Assert.assertEquals(formDemoPage.getFormDemoLabel(), "Form Demo", "\n Actual and expected page header is not same \n");
		formDemoPage.clickOnSubmit();
		String strMessage = formDemoPage.getMessage();
		Assert.assertEquals(strMessage.equals("Please fill out this field.") || strMessage.equals("Please fill in this field."), true, "\n Actual and expected message is not same \n");
		
		formDemoPage.enterName("Test");
		formDemoPage.enterinpEmail("test@gmail.com");
		formDemoPage.enterPassword("Test@11");
		formDemoPage.enterCompany("TestCompany");
		formDemoPage.enterWebsite("https://www.test11.com/");
		formDemoPage.selectCountry("United States");
		formDemoPage.enterCity("TestCity");
		formDemoPage.enterAddress1("TestAdd1");
		formDemoPage.enterAddress2("TestAdd2");
		formDemoPage.enterState("TestState");
		formDemoPage.enterZipCode("123123");
		formDemoPage.clickOnSubmit();
		
		Assert.assertEquals(formDemoPage.getFormValidationLabel(), "Input form validations", "\n Actual and expected page header is not same \n");
		Assert.assertEquals(formDemoPage.getSuccessMessage(), "Thanks for contacting us, we will get back to you shortly.", "\n Actual and expected success message is not same \n");
	}
}