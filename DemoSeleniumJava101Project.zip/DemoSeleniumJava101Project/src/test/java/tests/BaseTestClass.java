package tests;


import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import pages.BasePage;

public class BaseTestClass {

	protected BasePage basePage;
	public String username = "shubham_dokhale";
	public String accesskey = "UDWxxmumF1IvMfg0ZvicqAugJ8lkgLxuIksp0cyffkUnh2OI5n";
	public String gridURL = "@hub.lambdatest.com/wd/hub";
	RemoteWebDriver driver;

	@BeforeClass
	@Parameters(value = { "Browser", "Version", "Platform" })
	public void setUp(String browser, String version, String platform) throws MalformedURLException {

		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("browserName",browser);
		cap.setCapability("browserVersion", version);
		cap.setCapability("platformName", platform);

		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		ltOptions.put("username", "shubham_dokhale");
		ltOptions.put("accessKey", "UDWxxmumF1IvMfg0ZvicqAugJ8lkgLxuIksp0cyffkUnh2OI5n");
		ltOptions.put("visual", true);
		ltOptions.put("video", true);
		ltOptions.put("network", true);
		ltOptions.put("build", "Lambda Test Automation");
		ltOptions.put("console", true);
		ltOptions.put("terminal", true);
		ltOptions.put("devicelog", true);
		ltOptions.put("project", "LambdaSeleniumTest");
		ltOptions.put("selenium_version", "4.0.0");
		cap.setCapability("LT:Options", ltOptions);
		driver = new RemoteWebDriver(new URL("https://" + username + ":" + accesskey + gridURL), cap);

		((WebDriver) driver).manage().window().maximize();
		((WebDriver) driver).manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
	}

	@AfterClass
	public void tearDown() {
		((WebDriver) driver).quit();
	}

	@BeforeMethod
	@Parameters(value = { "URL" })
	public void loadApplication(String url) throws InterruptedException {
		driver.get("https://www.lambdatest.com/selenium-playground/");
		Thread.sleep(3000);
		basePage = new BasePage();
		basePage.setDriver(driver);
	}

}
