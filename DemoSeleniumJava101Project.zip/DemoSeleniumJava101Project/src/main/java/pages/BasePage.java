package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

public class BasePage {
	public static RemoteWebDriver driver;

	public void setDriver(RemoteWebDriver driver) {
		BasePage.driver = driver;
	}

	protected WebElement find(By locator) {
		return driver.findElement(locator);
	}

	protected void click(By locator) {
		find(locator).click();
	}

	protected String getText(By locator) {
		String text = find(locator).getText();
		System.out.println("Text is: " + text);
		return text;
	}

	protected void setText(By locator, String inpValue) {
		find(locator).sendKeys(inpValue);
		}

	
	public boolean isElementDisplayed(By locator) {
		return find(locator).isDisplayed();
	}

	public boolean isElementSelected(By locator) {
		return find(locator).isSelected();
	}
}
