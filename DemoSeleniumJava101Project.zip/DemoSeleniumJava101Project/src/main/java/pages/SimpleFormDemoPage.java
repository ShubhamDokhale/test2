package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SimpleFormDemoPage extends BasePage {

	private By hdrSimpleFormDemo = By.xpath("//h1[text()='Simple Form Demo']");
	private By inpEnterMessage = By.xpath("//p[text()='Enter Message']/following-sibling::input[@id='user-message']");
	private By btnGetCheckedValue = By.id("showInput");
	private By lblYourMessage = By.id("message");
	
	public String getPageURL() {
		String strURL = driver.getCurrentUrl();
		System.out.println("Cuurent page URL is: "+strURL);
		return strURL;
	} 
	
	public String getSimpleFormDemoLabel() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(hdrSimpleFormDemo));
		String strTitle = getText(hdrSimpleFormDemo);
		return strTitle;
	}
	
	public void enterMessage(String message) {
		setText(inpEnterMessage, message);
	}
	
	public void clickOnGetCheckedValue() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(btnGetCheckedValue ));
		click(btnGetCheckedValue);
	}
	
	public String getYourMessage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(lblYourMessage));
		String strMessage = getText(lblYourMessage);
		return strMessage;
	}
	
}
