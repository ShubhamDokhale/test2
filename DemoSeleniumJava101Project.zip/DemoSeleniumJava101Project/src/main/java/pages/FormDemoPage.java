package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FormDemoPage extends BasePage {

	private By hdrFormDemo = By.xpath("//h1[text()='Form Demo']");
	private By btnSubmit = By.xpath("//button[text()='Submit']");
	private By inpName = By.id("name");
	private By inpEmail = By.id("inputEmail4");
	private By inpPassword = By.id("inputPassword4");
	private By inpCompany = By.id("company");
	private By inpWebsite = By.id("websitename");
	private By drpCountry = By.xpath("//select[@name='country']");
	private By inpCity = By.id("inputCity");
	private By inpAddress1 = By.id("inputAddress1");
	private By inpAddress2 = By.id("inputAddress2");
	private By inpState = By.id("inputState");
	private By inpZipCode = By.id("inputZip");
	private By hdrFormValidation = By.xpath("//h2[text()='Input form validations']");
	private By lblSuccessMessage = By.xpath("//p[@class='success-msg hidden']");
	
	
	public String getPageURL() {
		String strURL = driver.getCurrentUrl();
		System.out.println("Cuurent page URL is: "+strURL);
		return strURL;
	} 
	
	public String getFormDemoLabel() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(hdrFormDemo));
		String strTitle = getText(hdrFormDemo);
		return strTitle;
	}

	public void clickOnSubmit() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(btnSubmit ));
		click(btnSubmit);
	}
	
	public String getMessage() {
		String strMessage = driver.findElement(inpName).getAttribute("validationMessage");
		System.out.println("Message is: "+ strMessage);
		return strMessage;
	}
	
	public void enterName(String name) {
		setText(inpName, name);
	}
	
	public void enterinpEmail(String email) {
		setText(inpEmail, email);
	}
	
	public void enterPassword(String password) {
		setText(inpPassword, password);
	}
	
	public void enterCompany(String company) {
		setText(inpCompany, company);
	}
	
	public void selectCountry(String country) {
		Select sel = new Select(driver.findElement(drpCountry));
		sel.selectByVisibleText(country);
	}
	
	public void enterWebsite(String website) {
		setText(inpWebsite, website);
	}
	
	public void enterCity(String city) {
		setText(inpCity, city);
	}
	
	public void enterAddress1(String address1) {
		setText(inpAddress1, address1);
	}
	
	public void enterAddress2(String address2) {
		setText(inpAddress2, address2);
	}

	public void enterState(String state) {
		setText(inpState, state);
	}
	
	public void enterZipCode(String zipCode) throws InterruptedException {
		setText(inpZipCode, zipCode);
		Thread.sleep(3000);
	}
	
	public String getFormValidationLabel() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(hdrFormValidation));
		String strTitle = getText(hdrFormValidation);
		return strTitle;
	}
	
	public String getSuccessMessage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(lblSuccessMessage));
		String strMessage = getText(lblSuccessMessage);
		System.out.println("Success message: " + strMessage);
	return strMessage;
	}

	
}
