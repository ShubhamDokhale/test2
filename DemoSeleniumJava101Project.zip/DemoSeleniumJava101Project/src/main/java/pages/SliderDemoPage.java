package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SliderDemoPage extends BasePage {

	private By hdrSliderDemo = By.xpath("//h1[text()='Slider Demo']");
	private By slider3 = By.xpath("//div[@id='slider3']//input");
	private By slider3Value = By.xpath("//div[@id='slider3']//output");
	
	
	public String getSliderDemoLabel() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(hdrSliderDemo));
		String strTitle = getText(hdrSliderDemo);
		return strTitle;
	}
	
	public String getSlider3Value() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.presenceOfElementLocated(slider3Value));
		String strTitle = getText(slider3Value);
		return strTitle;
	}
	
	public void setSliderRangeTo95() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(slider3));
		Actions act = new Actions(driver);
		act.moveToElement(driver.findElement(slider3)).clickAndHold().moveByOffset(215, 0).release().build().perform();
		//act.dragAndDropBy(driver.findElement(slider3), 215, 0).perform();
	}
	
}
